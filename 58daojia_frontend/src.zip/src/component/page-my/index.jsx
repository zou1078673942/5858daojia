import React from 'react';
function My () {
    return (
        <div className="home-wrapper">
            my
        </div>
    )
}
export default My