import React from 'react';
import './login_out.css'
export default function Login() {
    return (
        <div className='login_out'>
            <div className='btn'>
            退出登录
            </div>
        </div>
    )
}