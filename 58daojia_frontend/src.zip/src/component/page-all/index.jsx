import React from 'react';
function All () {
    return (
        <div className="home-wrapper">
            All
        </div>
    )
}
export default All