import styled from 'styled-components';

export const Gou = styled.div`
  position: relative;
  
  width:10rem;
  background-color: #fff;
    ul{
        position:relative;
        width:8.5rem;
        height:.8rem ;
        display: flex;
        justify-content:space-around;
        padding-right:1rem;
        left:.5rem;
        color:#808080;
        }
        li{
        position:relative;
          font-size:.4rem;
        }
      
`;
