import styled from 'styled-components';

export const Biaoyu = styled.div`
  position: relative;
  padding-top:.2rem;
  padding-left:.3rem ;
  padding-bottom:.3rem;
  width: 9.7rem;
  font-size:.37rem;
  color:#808080;
  background-color: #fff;
  display: flex;
`;
