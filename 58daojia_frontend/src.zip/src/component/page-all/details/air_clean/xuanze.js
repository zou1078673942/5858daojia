import styled from 'styled-components';

export const Xuanze = styled.div`
  position: relative;
  top:.28rem;
  width:10rem;
  height:6rem;
  
  border-radius:.2rem;
  .xuanze_title{
  position: relative;
    height:1.8rem ;
    width:10rem;
    display:flex;
    background-color:#fff;
    text-align:center;
    align-items:center;
  }
  .xuanze_title .head_title{
    width:1rem;
    height:2rem ;
    left:.5rem;
    display:flex;
    text-align:center;
    align-items:center;
    position: relative;

  }
  .xuanze_title .detail_title1{
    display:flex;
    left:.5rem;
    text-align:center;
    align-items:center;
    width:4rem;
    height:1.8rem ;
    position: relative;
  }
      
`;
