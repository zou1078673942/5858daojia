export const CHANGE_CITY = 'CHANGE_CITY'

export const changeCity = (data) => ({
    type: CHANGE_CITY,
    city: data
})