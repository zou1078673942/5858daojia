import React from 'react';
function Home () {
    return (
        <div className="home-wrapper">
            home
        </div>
    )
}
export default Home